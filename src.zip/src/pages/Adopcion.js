import React from 'react'

function Adopcion() {
  return (
    <div>
        Adopcion
    </div>
  )
}

export default Adopcion
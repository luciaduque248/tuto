import React from 'react'

function Aliados() {
  return (
    <div>Aliados</div>
  )
}

export default Aliados
import React from 'react'

function Donacion() {
  return (
    <div>Donacion</div>
  )
}

export default Donacion
import React from 'react'
import Footer from '../components/footer/Footer'
import Header from '../components/header/Header'

function Inicio() {
    return (
        <div>
            <Header/>
            <Footer/>
        </div>
    )
}

export default Inicio
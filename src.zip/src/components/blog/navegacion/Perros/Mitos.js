import React from 'react'

function Mitos() {
  return (
    <div>Mitos</div>
  )
}

export default Mitos
import React from 'react'

function Cuidados() {
  return (
    <div>Cuidados</div>
  )
}

export default Cuidados
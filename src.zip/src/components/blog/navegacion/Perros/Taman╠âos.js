import React from 'react'

function Tamaños() {
  return (
    <div>Tamaños</div>
  )
}

export default Tamaños